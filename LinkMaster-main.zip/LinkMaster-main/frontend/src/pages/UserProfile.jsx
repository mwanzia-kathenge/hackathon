// src/pages/UserProfile.js

import React from 'react';
import './styles/UserProfile.css';
const UserProfile = () => {
  return (
    <div>
      <h2>User Profiles</h2>
      <p>View and manage user profiles here.</p>
    </div>
  );
};

export default UserProfile;
