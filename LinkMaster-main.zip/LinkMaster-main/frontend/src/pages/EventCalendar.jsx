// src/pages/EventCalendar.js

import React from 'react';
import './styles/EventCalendar.css';
const EventCalendar = () => {
  return (
    <div>
      <h2>Event Calendar</h2>
      <p>Upcoming workshops and events.</p>
    </div>
  );
};

export default EventCalendar;
