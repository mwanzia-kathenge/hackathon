// src/pages/JobListing.js

import React from 'react';
import './styles/Auth.css';
const JobListing = () => {
  return (
    <div>
      <h2>Job Listings</h2>
      <p>Find job opportunities here.</p>
    </div>
  );
};

export default JobListing;
