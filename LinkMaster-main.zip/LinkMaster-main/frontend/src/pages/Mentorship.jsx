// src/pages/Mentorship.js

import React from 'react';
import './styles/Mentorship.css';
const Mentorship = () => {
  return (
    <div>
      <h2>Mentorship Programs</h2>
      <p>Connect with mentors and find guidance.</p>
    </div>
  );
};

export default Mentorship;
